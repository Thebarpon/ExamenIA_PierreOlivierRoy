using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FightState : IState
{
    public bool CanEnter()
    {
        //Verifier si ennemi a proximite et evaluer si il peut battre l'ennemi.
        throw new System.NotImplementedException();
    }

    public bool CanExit()
    {
        //Mettre la logic
        throw new System.NotImplementedException();
    }

    public void OnEnter()
    {
        //Informe des changements d'etats a des fin de debugage
        //Debug.Log();
        throw new System.NotImplementedException();
    }

    public void OnExit()
    {
        //Informe des changements d'etats a des fin de debugage
        //Debug.Log();
        throw new System.NotImplementedException();
    }

    public void Update()
    {
        //Logique de combat
        throw new System.NotImplementedException();
    }
}
