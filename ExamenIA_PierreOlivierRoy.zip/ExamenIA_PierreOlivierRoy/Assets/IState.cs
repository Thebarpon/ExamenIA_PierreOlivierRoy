using UnityEngine;

// Interface d�finissant les m�thodes et propri�t�s requises pour un �tat.

public interface IState
{
    // D�termine si l'�tat peut �tre entr�.
    bool CanEnter();

    // Appel� quand l'�tat est entr�.
    void OnEnter();

    // Mise � jour appel�e � chaque frame quand cet �tat est actif.
    void Update();

    // D�termine si l'�tat peut �tre quitt�.
    bool CanExit();

    // Appel� quand l'�tat est quitt�.
    void OnExit();
}