using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class StateMachine : MonoBehaviour
{

    //Permet de savoir l'etat actuel du personnage
    private IState currentState;

    //Liste scalable d'etat
    private List<IState> possibleStates = new List<IState>();

    //Permet aux etats d'avoir reference a l'agent navmesh
    private NavMeshAgent agent;

    //Permet de savoir la position de la cle
    [SerializeField]
    private Transform keyLocation;

    //Permet de savoir la position de la porte
    [SerializeField]
    private Transform doorLocation;

    private void Start()
    {
        //Prend les informations que le personnage doit transmettre au navmesh pour calculer les chemins et eventuellement passer ses informations aux states
        agent = GetComponent<NavMeshAgent>();

        //Creer et mettre dans sa banque d'etat les differents etats du personnage
        possibleStates.Add(new SearchState(agent,keyLocation,doorLocation));
        possibleStates.Add(new FightState());
        possibleStates.Add(new FleeState());

        //Mettre l'etat Search comme celui par defaut
        currentState = possibleStates[0];
    }
    private void Update()
    {
        //Verifier a chaque update si on peut changer d'etat et le faire
        StateTransition();

        //Update l'etat actuel APRES la verification afin que le personnage effectue la logique d'etat approprie a la frame actuel et non la precedente
        currentState.Update();
    }

    private void StateTransition()
    {
        //Null check pour la sante de notre state machine
        if (currentState == null) { return; }

        //Verifier si on peut quitter l'etat actuel
        if(currentState.CanExit())
        {
            //si on PEUT quitter l'etat actuel, regarder dans chaque etat si on peut y entrer.
            foreach(IState state in possibleStates) 
            {
                //Verifie si on peut entrer dans l'etat presentement evaluer
                if(state.CanEnter())
                {
                    //SEULEMENT si on peut entrer dans un autre etat, on applique la logique de sortie de l'etat precedent
                    currentState.OnExit();

                    //On change l'etat du personnage pour le nouvel etat
                    currentState = state;

                    //APRES avoir changer d'etat, on applique la logique d'enter du nouvel etat
                    currentState.OnEnter();

                    //On sauve du temps en arretant de chercher des etats une fois TOUTE la logique de transition d'etat applique
                    return;
                }
            }
        }
    }
}
