using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UIElements;

public class SearchState : IState
{
    private NavMeshAgent agent;
    private Transform keyLocation;
    private Transform doorLocation;
    private bool foundKey = false;

    private GameObject key;

    public SearchState(NavMeshAgent characterAgent, Transform sceneKeyLocation, Transform sceneDoorLocation) 
    {
        agent = characterAgent;
        keyLocation = sceneKeyLocation;
        doorLocation = sceneDoorLocation;
    }
    public bool CanEnter()
    {
        //Verifier si ennemi a proximite
        return true;
    }

    public bool CanExit()
    {
        //Verifier si ennemi a proximite
        return false;
    }

    public void OnEnter()
    {
        //Informe des changements d'etats a des fin de debugage
        Debug.Log("Enter search state");

        //Indique au navmesh la position ou doit aller l'agent et les informations de l'agent afin qu'il puisse determiner le trajet en prenant en compte les chemins possibles du navmesh
        agent.SetDestination(keyLocation.position);
    }

    public void OnExit()
    {
        //Informe des changements d'etats a des fin de debugage
        Debug.Log("Exit search state");
    }

    public void Update()
    {
        //Verifier si la cle est a porte
        CheckKeyDistance();

        //Verifier si la cle a ete trouve
        if(foundKey) 
        { 
            //Changer la destination pour la porte SI la cle a ete trouve
            agent.SetDestination(doorLocation.position); 
        }
        else
        {
            //Navmesh envoi une seul fois une commande a la composante agent afin de l'envoyer vers une destination.Si pour quelquonque raison le personnage
            //arrete son deplacement, il ne le reprendra pas apres.Par mesure de securite on envoi la destination ou aller a chaque update.
            agent.SetDestination(keyLocation.position);
        }
    }

    private void CheckKeyDistance()
    {
        //Calculer la distance entre le personnage et la cle
        float distance = Vector3.Distance(agent.transform.position, keyLocation.position);
        
        //Si le personnage touche la cle
        if (distance < 1)
        {
            //Indiquer que la cle est trouve
            foundKey = true;
        }
    }
}
