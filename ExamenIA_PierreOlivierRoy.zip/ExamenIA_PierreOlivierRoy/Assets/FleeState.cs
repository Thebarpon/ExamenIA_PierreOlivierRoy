using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FleeState : IState
{
    public bool CanEnter()
    {
        //Verifier si ennemi a proximite et evaluer si il doit fuire l'ennemi.
        throw new System.NotImplementedException();
    }

    public bool CanExit()
    {
        //Verifier si ennemi a proximite et evaluer si il doit fuire ou combattre l'ennemi. S'il doit toujour fuire il ne quitte pas le state
        throw new System.NotImplementedException();
    }

    public void OnEnter()
    {
        //Informe des changements d'etats a des fin de debugage
        //Debug.Log();
        throw new System.NotImplementedException();
    }

    public void OnExit()
    {
        //Informe des changements d'etats a des fin de debugage
        //Debug.Log();
        throw new System.NotImplementedException();
    }

    public void Update()
    {
        //Logique de fuite
        throw new System.NotImplementedException();
    }
}
